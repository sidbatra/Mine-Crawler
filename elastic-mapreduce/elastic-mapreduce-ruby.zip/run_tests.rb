#
# Copyright 2008-2010 Amazon.com, Inc. or its affiliates.  All Rights Reserved.

$LOAD_PATH << File.dirname(__FILE__)

require 'tests/commands_test'


